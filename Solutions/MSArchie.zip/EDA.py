import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns


class ExploratoryDataAnalysis:
    def __init__(self):
        pass
        
    def convert_missing_to_null(self, df, missing_value):
        
        df.replace(missing_value, np.nan, inplace=True)
        return df
    

    def describe_data(self, df):
       
        print(f"********** shape of dataframe is **************:\n {df.shape}\n")
        print(f"********** dataframe info is **********:\n {df.info()}")
        print(f"************** dataframe column stats are **************:\n {df.describe()}\n")
        print(f"************** displaying first 5 rows of dataframe **************:\n {df.head()}\n")
        print(f"************** number of NAs in each column is **************:\n {df.isna().sum()}\n")
        ### Print number of negative values in each column
        for col in df.columns:
            print(f"******** Number of negative values in each column is *****************: \n {col}\t{df[col][df[col]<0].shape[0]}")
        return None
    

    def plot_log_tracks(self, df):
        """ This function plots all log tracks side-by-side
        
        :param df: Dataframe with different logs
        :type df: Dataframe
        """
        _, ax = plt.subplots(1, df.shape[1], sharey=True, figsize=(30,18))
        i=0
        for col in df.columns:
            ax[i].scatter(df[col], df.index)
            ax[i].set_xlabel(col, fontsize=15)
            ax[i].set_ylabel("row number")
            ax[i].invert_yaxis()
            i+=1        
        return None


    def plot_sns_boxplot(self, df, nrows, ncols):
        """[summary]
        
        :param df: [description]
        :type df: [type]
        :param nrows: [description]
        :type nrows: [type]
        :param ncols: [description]
        :type ncols: [type]
        """
        _, ax = plt.subplots(nrows, ncols, figsize=(12,12))

        i = 0
        for col in df.columns:
            rownum = i//nrows
            colnum = i%ncols
            sns.boxplot(df[col], ax=ax[rownum, colnum])
            i+=1
        return None
    

    def heat_map(self, df):
        plt.figure(figsize=(12,12))
        sns.heatmap(df.corr(), annot=True, cmap='RdYlGn')
        return None


    def exploratory_plots(self, df):
        self.plot_log_tracks(df)
        df.hist(figsize=(12,12))
        self.plot_sns_boxplot(df, 3, 3)
        self.heat_map(df)


