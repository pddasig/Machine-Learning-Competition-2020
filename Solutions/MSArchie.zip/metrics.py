from sklearn.metrics import  mean_squared_error, r2_score, \
    explained_variance_score, mean_absolute_error, mean_squared_log_error
import matplotlib.pylab as plt
import pandas as pd
import numpy as np

def get_rmse(y_true, y_pred):
    _rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    return _rmse
def get_nrmse(y_true, y_pred):
    _nrmse = get_rmse(y_true, y_pred) / np.mean(y_true)
    return _nrmse

def get_neg_mean_squared_error(y_true, y_pred):
    return -(mean_squared_error(y_true, y_pred))

def get_rmsle(y_true, y_pred):
    _rmsle = np.sqrt(mean_squared_log_error(y_true, y_pred))
    return _rmsle

def get_mape(y_true, y_pred):
    try:
        _mape = np.mean(np.abs((y_true - y_pred) / y_true)) * 100
    except ZeroDivisionError:
        epsilon = 0.000000001
        _mape = np.mean(np.abs((y_true - y_pred) / (y_true + epsilon))) * 100
    return _mape

def get_metrics(y_true, y_pred):
    metrics = {}
    metrics['root_mean_squared_error'] = get_rmse(y_true, y_pred)
    metrics['normalized_root_mean_squared_error'] = get_nrmse(y_true, y_pred)
    metrics['neg_mean_squared_error'] = get_neg_mean_squared_error(y_true, y_pred)
    metrics['root mean squared log error'] = get_rmsle(y_true, y_pred)
    metrics['mean absolute percentage error'] = get_mape(y_true, y_pred)
    metrics['r2_score'] = r2_score(y_true, y_pred)
    metrics['mean_absolute_error'] = mean_absolute_error(y_true, y_pred)
    metrics["explained_variance"] = explained_variance_score(y_true, y_pred)
    
    return pd.Series(list(metrics.values()), index=metrics.keys())


# +
def show_residual(residual, description, _color):   
    plt.figure()
    f, (a0, a1) = plt.subplots(
        1, 2, gridspec_kw={"width_ratios": [3, 1], "wspace": 0, "hspace": 0}
    )

    f.set_figheight(6)
    f.set_figwidth(14)

    a0.plot(residual, "o", color=_color, alpha=0.4)
    a0.plot([0, len(residual)], [0, 0], "k", lw=2)
    a0.set_ylabel("Residual Values", fontsize=14)
    a0.set_xlabel(description, fontsize=14)

    a1.hist(residual, orientation="horizontal", color=_color, bins=10, histtype="step")
    a1.hist(residual, orientation="horizontal", color=_color, alpha=0.2, bins=10)
    a1.set_yticklabels([])
    return f

def show_actual_vs_prediction_plot(y_pred, y_true, _target, data):
    fig, ax = plt.subplots(figsize=(8, 8))
    if data == "Training Data":
        _color = "steelblue"
    else:
        _color = "orange"
    plt.scatter(y_pred, y_true, marker="o", color=_color)

    line45 = np.linspace(
        np.min((y_pred.min(), y_true.min())), np.max((y_pred.max(), y_true.max()))
    )
    plt.plot(line45, line45, color="k", ls="--")
    plt.grid(color="y", linestyle=":", linewidth=1, alpha=0.5)
    plt.xlabel(_target + "_predicted")
    plt.ylabel(_target + "_actual")
    plt.title("Actual vs. Prediction : " + data)
    ax.set_aspect("equal")
    return fig
